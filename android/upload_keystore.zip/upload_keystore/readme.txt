<<<<<<<======   Showup To Meetup ======>>>>>>>


==>>>> Tome tracker JKS File <<<<==


1. when use need use the <<<< upload-keystore.jks >>> file.
2. then change the extension of the <<< upload-keystore.txt >>>  to  <<< upload-keystore.jks >>> and then use it.



==>>>> Reference the keystore from the app <<<<==

    
1. Create a file named [project]/android/key.properties that contains a reference to your keystore:
2. below key.properties data


storePassword=KVuPSh4N4bmRdcO
keyPassword=KVuPSh4N4bmRdcO
keyAlias=upload
storeFile=../app/upload-keystore.jks



Thenk you so much.